@extends ('partial.main')

@section('container')
    <script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.1/datepicker.min.js"></script>
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <link type="text/css" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/south-street/jquery-ui.css"
        rel="stylesheet">
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jSignature/2.1.2/jSignature.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/jSignature/2.1.2/jquery.signaturepad.css">
    
    <style>
        .kbw-signature {
            width: 100%;
            height: 200px;
        }

        .signature canvas {
            width: 100% !important;
            height: 200px !important;
        }
    </style>
    <form method="POST" action="{{ Route('form-update', $mustahik->id) }}" class="pt-20 mx-2 flex flex-col space-y-4 max-w-screen-xl mx-auto" enctype="multipart/form-data">
        @csrf
        @method('PUT')
        <section id="identitas_mustahik" class="space-y-4">
            <p class="block py-4 text-base font-semibold text-black">
                I. Identitas Mustahik
            </p>

            <div class="gap-4">
                <div class="space-y-4">
                    <div>
                        <label for="nama_mustahik" class="block mb-2 text-xs font-medium text-black">Nama Mustahik</label>
                        <input name="nama_mustahik" type="text" id="nama_mustahik"
                            class="shadow-sm bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5"
                            value="{{ $mustahik->nama_mustahik }}" required>
                    </div>

                    <div>
                        <label for="nama_kepala_keluarga" class="block mb-2 text-xs font-medium text-black">Nama Kepala
                            Keluarga</label>
                        <input name="nama_kepala_keluarga" type="text" id="nama_kepala_keluarga"
                            class="shadow-sm bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5"
                            value="{{ $mustahik->nama_kepala_keluarga }}" required>
                    </div>

                    <div class="flex justify-between gap-2">
                        <div class="w-1/2">
                            <label for="jenis_kelamin" class="block mb-2 text-xs font-medium text-black">Jenis
                                Kelamin</label>
                            <select name="jenis_kelamin" id="jenis_kelamin"
                                class="bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5">
                                <option value="Laki-laki" @if($mustahik->jenis_kelamin == 'Laki-laki') selected @endif>Laki-laki</option>
                                <option value="Perempuan" @if($mustahik->jenis_kelamin == 'Perempuan') selected @endif>Perempuan</option>
                            </select>
                        </div>

                        <div class="w-1/2">
                            <label for="usia" class="block mb-2 text-xs font-medium text-black">Usia</label>
                            <input name="usia" type="number" id="usia"
                                class="shadow-sm bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5"
                                value="{{ $mustahik->usia }}" required>
                        </div>
                    </div>

                    <div>
                        <label for="no_ktp_kk" class="block mb-2 text-xs font-medium text-black">No. KTP / KK</label>
                        <input name="no_ktp_kk" type="text" id="no_ktp_kk"
                            class="shadow-sm bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5"
                            value="{{ $mustahik->no_ktp_kk }}" required>
                    </div>
                </div>

                <div class="space-y-4 mt-2">
                    <div>
                        <label for="alamat" class="block mb-2 text-xs font-medium text-black">Alamat</label>
                        <textarea name="alamat" id="alamat" rows="3"
                            class="block p-2.5 w-full text-sm text-black bg-gray-50 rounded-lg border border-gray-300 focus:ring-green-500 focus:border-green-500"
                            required>{{ $mustahik->alamat }}</textarea>
                    </div>
                    <div class="flex justify-between gap-2">
                        <div class="flex flex-col w-1/3">
                            <label for="rt" class="block mb-2 text-xs font-medium text-black">RT</label>
                            <input name="rt" type="text" id="rt"
                                class="shadow-sm bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5"
                                value="{{ $mustahik->rt }}" required>
                        </div>
                        <div class="flex flex-col w-1/3">
                            <label for="rw" class="block mb-2 text-xs font-medium text-black">RW</label>
                            <input name="rw" type="text" id="rw"
                                class="shadow-sm bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5"
                                value="{{ $mustahik->rw }}" required>
                        </div>
                        <div class="flex flex-col w-1/3">
                            <label for="kelurahan" class="block mb-2 text-xs font-medium text-black">Kelurahan</label>
                            <input name="kelurahan" type="text" id="kelurahan"
                                class="shadow-sm bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5"
                                value="{{ $mustahik->kelurahan }}" required>
                        </div>
                    </div>
                    <div class="flex gap-2 justify-between">
                        <div class="w-1/2">
                            <label for="kecamatan" class="block mb-2 text-xs font-medium text-black">Kecamatan</label>
                            <input name="kecamatan" type="text" id="kecamatan"
                                class="shadow-sm bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5"
                                value="{{ $mustahik->kecamatan }}" required>
                        </div>

                        <div class="w-1/2">
                            <label for="kota" class="block mb-2 text-xs font-medium text-black">Kota</label>
                            <input name="kota" type="text" id="kota"
                                class="shadow-sm bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5"
                                value="{{ $mustahik->kota }}" required>
                        </div>
                    </div>


                    <div class="space-y-4">
                        <div>
                            <label for="no_telp" class="block mb-2 text-xs font-medium text-black">No. Telepon</label>
                            <input name="no_telp" type="tel" id="no_telp"
                                class="shadow-sm bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5"
                                value="{{ $mustahik->no_telp }}" required>
                        </div>

                        <div>
                            <label for="pekerjaan" class="block mb-2 text-xs font-medium text-black">Pekerjaan</label>
                            <input name="pekerjaan" type="text" id="pekerjaan"
                                class="shadow-sm bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5"
                                value="{{ $mustahik->pekerjaan }}" required>
                        </div>

                        <div>
                            <label for="agama" class="block mb-2 text-xs font-medium text-black">Agama</label>
                            <input name="agama" type="text" id="agama"
                                class="shadow-sm bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5"
                                value="{{ $mustahik->agama }}" required>
                        </div>
                    </div>
                </div>

                <div class="grid gap-4 mt-4">
                    <div class="space-y-4">
                        <div>
                            <label for="nama_diwawancarai" class="block mb-2 text-xs font-medium text-black">Nama yang
                                Diwawancarai</label>
                            <input name="nama_diwawancarai" type="text" id="nama_diwawancarai"
                                class="shadow-sm bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5"
                                value="{{ $mustahik->nama_diwawancarai }}" required>
                        </div>

                        <div>
                            <label for="no_telp_diwawancarai" class="block mb-2 text-xs font-medium text-black">No.
                                Telepon yang Diwawancarai</label>
                            <input name="no_telp_diwawancarai" type="tel" id="no_telp_diwawancarai"
                                class="shadow-sm bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5"
                                value="{{ $mustahik->no_telp_diwawancarai }}" required>
                        </div>

                        <div>
                            <label for="hubungan" class="block mb-2 text-xs font-medium text-black">Hubungan</label>
                            <input name="hubungan" type="text" id="hubungan"
                                class="shadow-sm bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5"
                                value="{{ $mustahik->hubungan }}" required>
                        </div>
                    </div>

                    <div class="space-y-4">
                        <div>
                            <label for="nomor_index" class="block mb-2 text-xs font-medium text-black">Nomor Index</label>
                            <input name="nomor_index" type="text" id="nomor_index"
                                class="shadow-sm bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5"
                                value="{{ $mustahik->nomor_index }}" required>
                        </div>

                        <div>
                            <label for="jenis_bantuan" class="block mb-2 text-xs font-medium text-black">Jenis
                                Bantuan</label>
                            <input name="jenis_bantuan" type="text" id="jenis_bantuan"
                                class="shadow-sm bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5"
                                value="{{ $mustahik->jenis_bantuan }}" required>
                        </div>

                        <div>
                            <label for="tanggal_survey" class="block mb-2 text-xs font-medium text-black">Tanggal
                                Survey</label>
                            <input name="tanggal_survey" type="date" id="tanggal_survey"
                                class="shadow-sm bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5"
                                value="{{ \Carbon\Carbon::parse($mustahik->tanggal_survey)->format('Y-m-d') }}" required>
                        </div>
                    </div>
                </div>
        </section>
        <section id="profil_keluarga" class="my-4 space-y-4 analisis">
            <p class="block py-4 text-base font-semibold text-black">
                II. Profil Keluarga
            </p>

            <div class="space-y-4">
                <div>
                    <label for="status_pernikahan" class="block mb-2 text-xs font-medium text-black">1. Status Pernikahan
                        Kepala Keluarga</label>
                    <select name="status_pernikahan" id="status_pernikahan"
                        class="bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5">
                        <option value="5" {{ $mustahik->status_pernikahan == '5' ? 'selected' : '' }}>Janda</option>
                        <option value="4" {{ $mustahik->status_pernikahan == '4' ? 'selected' : '' }}>Duda</option>
                        <option value="3" {{ $mustahik->status_pernikahan == '3' ? 'selected' : '' }}>Menikah</option>
                        <option value="2" {{ $mustahik->status_pernikahan == '2' ? 'selected' : '' }}>Bujang</option>
                    </select>
                </div>

                <div>
                    <label for="jumlah_anggota" class="block mb-2 text-xs font-medium text-black">2. Jumlah Anggota /
                        Tanggungan keluarga dalam 1 rumah (Suami, istri, orang tua, mertua)</label>
                    <select name="jumlah_anggota" id="jumlah_anggota"
                        class="bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5">
                        <option value="5" {{ $mustahik->jumlah_anggota == '5' ? 'selected' : '' }}>diatas 6</option>
                        <option value="4" {{ $mustahik->jumlah_anggota == '4' ? 'selected' : '' }}>4 s/d 6</option>
                        <option value="3" {{ $mustahik->jumlah_anggota == '3' ? 'selected' : '' }}>1 s/d 3</option>
                        <option value="2" {{ $mustahik->jumlah_anggota == '2' ? 'selected' : '' }}>tidak ada</option>
                    </select>
                </div>

                <div>
                    <label for="usia_kepala" class="block mb-2 text-xs font-medium text-black">3. Usia Kepala
                        Keluarga</label>
                    <select name="usia_kepala" id="usia_kepala"
                        class="bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5">
                        <option value="5" {{ $mustahik->usia_kepala == '5' ? 'selected' : '' }}>diatas 55 tahun</option>
                        <option value="4" {{ $mustahik->usia_kepala == '4' ? 'selected' : '' }}>51 s/d 55</option>
                        <option value="3" {{ $mustahik->usia_kepala == '3' ? 'selected' : '' }}>40 s/d 50</option>
                        <option value="2" {{ $mustahik->usia_kepala == '2' ? 'selected' : '' }}>30 s/d 40</option>
                        <option value="1" {{ $mustahik->usia_kepala == '1' ? 'selected' : '' }}>di bawah 30</option>
                    </select>
                </div>

                <div>
                    <label for="anggota_hamil" class="block mb-2 text-xs font-medium text-black">4. Anggota keluarga ada
                        yang hamil atau memiliki balita/batita</label>
                    <select name="anggota_hamil" id="anggota_hamil"
                        class="bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5">
                        <option value="4" {{ $mustahik->anggota_hamil == '4' ? 'selected' : '' }}>Ya</option>
                        <option value="3" {{ $mustahik->anggota_hamil == '3' ? 'selected' : '' }}>Tidak</option>
                    </select>
                </div>

                <div>
                    <label for="anak_usia_sekolah" class="block mb-2 text-xs font-medium text-black">5. Jumlah Anak Usia
                        Sekolah</label>
                    <select name="anak_usia_sekolah" id="anak_usia_sekolah"
                        class="bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5">
                        <option value="5" {{ $mustahik->anak_usia_sekolah == '5' ? 'selected' : '' }}>diatas 3</option>
                        <option value="4" {{ $mustahik->anak_usia_sekolah == '4' ? 'selected' : '' }}>1 s/d 3</option>
                        <option value="3" {{ $mustahik->anak_usia_sekolah == '3' ? 'selected' : '' }}>tidak ada</option>
                    </select>
                </div>

                <div>
                    <label for="orang_tua_uzur" class="block mb-2 text-xs font-medium text-black">6. Ada Orang Tua Selain
                        Kepala Keluarga yang Sudah Uzur (diatas 55 tahun)</label>
                    <select name="orang_tua_uzur" id="orang_tua_uzur"
                        class="bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5">
                        <option value="4" {{ $mustahik->orang_tua_uzur == '4' ? 'selected' : '' }}>Ya</option>
                        <option value="3" {{ $mustahik->orang_tua_uzur == '3' ? 'selected' : '' }}>Tidak</option>
                    </select>
                </div>

                <div>
                    <label for="anggota_penyakit_berat" class="block mb-2 text-xs font-medium text-black">7. Ada Anggota
                        yang Memiliki Penyakit Berat</label>
                    <select name="anggota_penyakit_berat" id="anggota_penyakit_berat"
                        class="bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5">
                        <option value="4" {{ $mustahik->anggota_penyakit_berat == '4' ? 'selected' : '' }}>Ya</option>
                        <option value="3" {{ $mustahik->anggota_penyakit_berat == '3' ? 'selected' : '' }}>Tidak</option>
                    </select>
                </div>
                <div>
                    <label for="anggota_cacat_fisik" class="block mb-2 text-xs font-medium text-black">8. Jumlah Anggota
                        Keluarga yang Memiliki Cacat Fisik</label>
                    <select name="anggota_cacat_fisik" id="anggota_cacat_fisik"
                        class="bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5">
                        <option value="4" {{ $mustahik->anggota_cacat_fisik == '4' ? 'selected' : '' }}>Ya</option>
                        <option value="3" {{ $mustahik->anggota_cacat_fisik == '3' ? 'selected' : '' }}>Tidak</option>
                    </select>
                </div>
            </div>
        </section>
        <section id="identifikasi_ketenagakerjaan_penghasilan" class="my-4 space-y-4 analisis">
            <p class="block py-4 text-base font-semibold text-black">
                III. Identifikasi Ketenagakerjaan dan Penghasilan Keluarga
            </p>

            <div class="space-y-4">
                <div>
                    <label for="penghasilan_utama_kepala" class="block mb-2 text-xs font-medium text-black">9. Penghasilan
                        Utama Kepala Keluarga</label>
                    <div class="flex gap-2">
                        <div class="flex w-1/2">
                            <div
                                class="text-center self-center text-xs font-medium text-black bg-gray-200 rounded-l-lg p-3 border border-gray-300">
                                Rp.
                            </div>
                            <input type="text" data-type="money"  value="{{ $mustahik->penghasilan_utama_kepala }}" name="jumlah_utama_kepala" id="jumlah_utama_kepala"
                                class="bg-gray-50 border border-gray-300 text-black text-sm rounded-r-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5"
                                placeholder="Masukkan jumlah dalam Rupiah">
                        </div>
                        <select name="penghasilan_utama_kepala" id="penghasilan_utama_kepala"
                            class="bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block p-2.5 w-1/2">
                            <option value="5" {{ $mustahik->penghasilan_utama_kepala == '5' ? 'selected' : '' }}>Tidak Ada</option>
                            <option value="4" {{ $mustahik->penghasilan_utama_kepala == '4' ? 'selected' : '' }}>Buruh/ Tani serabutan/ Tng Kontrak</option>
                            <option value="3" {{ $mustahik->penghasilan_utama_kepala == '3' ? 'selected' : '' }}>Dagang/ Tani/ Ternak/ Produksi Jasa Kecil</option>
                            <option value="2" {{ $mustahik->penghasilan_utama_kepala == '2' ? 'selected' : '' }}>Karyawan/ Pegawai/ Home Industri</option>
                            <option value="1" {{ $mustahik->penghasilan_utama_kepala == '1' ? 'selected' : '' }}>PNS/ Pengusaha/ Industri</option>
                        </select>
                    </div>
                </div>

                <div>
                    <label for="penghasilan_anggota_2" class="block mb-2 text-xs font-medium text-black">10. Penghasilan
                        Anggota Keluarga 2</label>
                    <div class="flex gap-2">
                        <div class="flex w-1/2">
                            <div
                                class="w-1/6 text-center self-center text-xs font-medium text-black bg-gray-200 rounded-l-lg p-3 border border-gray-300">
                                Rp.
                            </div>
                            <input type="text" data-type="money"  value="{{ $mustahik->penghasilan_anggota_2 }}" name="penghasilan_anggota_2"
                                id="penghasilan_anggota_2"
                                class="bg-gray-50 border border-gray-300 text-black text-sm rounded-r-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5"
                                placeholder="Masukkan jumlah dalam Rupiah">
                        </div>
                        <select name="pekerjaan_anggota_2" id="pekerjaan_anggota_2"
                            class="bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block p-2.5 w-1/2">
                            <option value="5" {{ $mustahik->pekerjaan_anggota_2 == '5' ? 'selected' : '' }}>Tidak Ada</option>
                            <option value="4" {{ $mustahik->pekerjaan_anggota_2 == '4' ? 'selected' : '' }}>Buruh/ Tani serabutan/ Tng Kontrak</option>
                            <option value="3" {{ $mustahik->pekerjaan_anggota_2 == '3' ? 'selected' : '' }}>Dagang/ Tani/ Ternak/ Produksi Jasa Kecil</option>
                            <option value="2" {{ $mustahik->pekerjaan_anggota_2 == '2' ? 'selected' : '' }}>Karyawan/ Pegawai/ Home Industri</option>
                            <option value="1" {{ $mustahik->pekerjaan_anggota_2 == '1' ? 'selected' : '' }}>PNS/ Pengusaha/ Industri</option>
                        </select>
                    </div>
                </div>

                <div>
                    <label for="penghasilan_anggota_lain" class="block mb-2 text-xs font-medium text-black">11.
                        Penghasilan Anggota Keluarga Lain</label>
                    <div class="flex gap-2">
                        <div class="flex w-1/2">
                            <div
                                class="w-1/6 text-center self-center text-xs font-medium text-black bg-gray-200 rounded-l-lg p-3 border border-gray-300">
                                Rp.
                            </div>
                            <input type="text" data-type="money"  value="{{ $mustahik->penghasilan_anggota_lain }}" name="penghasilan_anggota_lain"
                                id="penghasilan_anggota_lain"
                                class="bg-gray-50 border border-gray-300 text-black text-sm rounded-r-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5"
                                placeholder="Masukkan jumlah dalam Rupiah">
                        </div>
                        <select name="pekerjaan_anggota_lain" id="pekerjaan_anggota_lain"
                            class="bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block p-2.5 w-1/2">
                            <option value="4" {{ $mustahik->pekerjaan_anggota_lain == '4' ? 'selected' : '' }}>Tidak Ada</option>
                            <option value="3" {{ $mustahik->pekerjaan_anggota_lain == '3' ? 'selected' : '' }}>Buruh/ Tani serabutan/ Tng Kontrak</option>
                            <option value="2" {{ $mustahik->pekerjaan_anggota_lain == '2' ? 'selected' : '' }}>Dagang/ Tani/ Ternak/ Produksi Jasa Kecil</option>
                            <option value="1" {{ $mustahik->pekerjaan_anggota_lain == '1' ? 'selected' : '' }}>Karyawan/ Pegawai/ PNS</option>
                        </select>
                    </div>
                </div>

                <div>
                    <label for="pendapatan_aset_sewa" class="block mb-2 text-xs font-medium text-black">12. Pendapatan
                        dari Aset yang Disewakan</label>
                    <div class="flex gap-2">
                        <div class="flex w-1/2">
                            <div
                                class="w-1/6 text-center self-center text-xs font-medium text-black bg-gray-200 rounded-l-lg p-3 border border-gray-300">
                                Rp.
                            </div>
                            <input type="text" data-type="money"  value="{{ $mustahik->pendapatan_aset_sewa }}" name="pendapatan_aset_sewa"
                                id="pendapatan_aset_sewa"
                                class="bg-gray-50 border border-gray-300 text-black text-sm rounded-r-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5"
                                placeholder="Masukkan jumlah dalam Rupiah">
                        </div>
                        <select name="jenis_aset_sewa" id="jenis_aset_sewa"
                            class="bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block p-2.5 w-1/2">
                            <option value="4" {{ $mustahik->jenis_aset_sewa == '4' ? 'selected' : '' }}>Tidak Ada</option>
                            <option value="2" {{ $mustahik->jenis_aset_sewa == '2' ? 'selected' : '' }}>Alat Produksi/ Kendaraan</option>
                            <option value="1" {{ $mustahik->jenis_aset_sewa == '1' ? 'selected' : '' }}>Tanah/ Rumah/ Kios/ Kontrakan</option>
                        </select>
                    </div>
                </div>

                <div>
                    <label for="penerimaan_bantuan_pendidikan" class="block mb-2 text-xs font-medium text-black">13.
                        Penerimaan Bantuan Pendidikan dari Pemerintah dan Pihak Lain</label>
                    <div class="flex gap-2">

                        <select name="jenis_bantuan_pendidikan" id="jenis_bantuan_pendidikan"
                            class="bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block p-2.5 w-full">
                            <option value="4" {{ $mustahik->jenis_bantuan_pendidikan == '4' ? 'selected' : '' }}>Tidak Ada</option>
                            <option value="2" {{ $mustahik->jenis_bantuan_pendidikan == '2' ? 'selected' : '' }}>KPJ/KJMU</option>
                            <option value="1" {{ $mustahik->jenis_bantuan_pendidikan == '1' ? 'selected' : '' }}>Program Beasiswa</option>
                        </select>
                    </div>
                </div>

                <div>
                    <label for="pendapatan_bulanan_lain" class="block mb-2 text-xs font-medium text-black">14. Pendapatan
                        Bulanan Lain di Luar Usaha Pokok</label>
                    <div class="flex gap-2">
                        <div class="flex w-1/2">
                            <div
                                class="w-1/6 text-center self-center text-xs font-medium text-black bg-gray-200 rounded-l-lg p-3 border border-gray-300">
                                Rp.
                            </div>
                            <input type="text" data-type="money"  value="{{ $mustahik->pendapatan_bulanan_lain }}" name="pendapatan_bulanan_lain"
                                id="pendapatan_bulanan_lain"
                                class="bg-gray-50 border border-gray-300 text-black text-sm rounded-r-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5"
                                placeholder="Masukkan jumlah dalam Rupiah">
                        </div>
                        <select name="jenis_pendapatan_lain" id="jenis_pendapatan_lain"
                            class="bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block p-2.5 w-1/2">
                            <option value="3" {{ $mustahik->jenis_pendapatan_lain == '3' ? 'selected' : '' }}>Tidak ada</option>
                            <option value="1" {{ $mustahik->jenis_pendapatan_lain == '1' ? 'selected' : '' }}>Ada</option>
                        </select>
                    </div>
                </div>

                <div>
                    <label for="kategori_penghasilan" class="block mb-2 text-xs font-medium text-black">15. Kategori
                        Penghasilan per Bulan</label>
                    <select name="kategori_penghasilan" id="kategori_penghasilan"
                        class="bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5">
                        <option value="5" {{ $mustahik->kategori_penghasilan == '5' ? 'selected' : '' }}>
                            < Rp 1.000.000</option>
                        <option value="4" {{ $mustahik->kategori_penghasilan == '4' ? 'selected' : '' }}>Rp 1.000.000 - Rp 2.500.000</option>
                        <option value="3" {{ $mustahik->kategori_penghasilan == '3' ? 'selected' : '' }}>Rp 2.500.000 - Rp 5.000.000</option>
                        <option value="2" {{ $mustahik->kategori_penghasilan == '2' ? 'selected' : '' }}>Rp 5.000.000 - Rp 7.000.000</option>
                        <option value="1" {{ $mustahik->kategori_penghasilan == '1' ? 'selected' : '' }}>> Rp 7.000.000</option>
                    </select>
                </div>
            </div>
        </section>
        <section id="identifikasi_pengeluaran_keluarga" class="my-4 space-y-4 analisis">
            <p class="block py-4 text-base font-semibold text-black">
                IV. Identifikasi Pengeluaran Keluarga
            </p>

            <div class="space-y-4">
                <div>
                    <label for="konsumsi_pangan" class="block mb-2 text-xs font-medium text-black">16. Konsumsi Pangan(Makanan Pokok, Sayur Mayur, Makanan Kering, Daging, Ikan, Susu, Telur, Dll)</label>
                    <div class="flex gap-2">
                        <div class="flex w-1/2">
                            <div class="text-center self-center text-xs font-medium text-black bg-gray-200 rounded-l-lg p-3 border border-gray-300">
                                Rp.
                            </div>
                            <input type="text" data-type="money"  value="{{ $mustahik->konsumsi_pangan }}" name="konsumsi_pangan" id="konsumsi_pangan"
                                class="bg-gray-50 border border-gray-300 text-black text-sm rounded-r-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5"
                                placeholder="Masukkan jumlah dalam Rupiah">
                        </div>
                        <select name="jenis_konsumsi_pangan" id="jenis_konsumsi_pangan"
                            class="bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block p-2.5 w-1/2">
                            <option value="5" {{ $mustahik->jenis_konsumsi_pangan == '5' ? 'selected' : '' }}>
                                < Rp 1.000.000</option>
                            <option value="4" {{ $mustahik->jenis_konsumsi_pangan == '4' ? 'selected' : '' }}>Rp 1.000.000 - Rp 2.000.000</option>
                            <option value="3" {{ $mustahik->jenis_konsumsi_pangan == '3' ? 'selected' : '' }}>Rp 2.000.000 - Rp 3.000.000</option>
                            <option value="2" {{ $mustahik->jenis_konsumsi_pangan == '2' ? 'selected' : '' }}>Rp 3.000.000 - Rp 3.500.000</option>
                            <option value="1" {{ $mustahik->jenis_konsumsi_pangan == '1' ? 'selected' : '' }}>> Rp 3.500.000</option>
                        </select>
                    </div>
                </div>

                <div>
                    <label for="konsumsi_rokok" class="block mb-2 text-xs font-medium text-black">17. Konsumsi Rokok/Tembakau dalam 1 Bulan</label>
                    <div class="flex gap-2">
                        <div class="flex w-1/2">
                            <div class="text-center self-center text-xs font-medium text-black bg-gray-200 rounded-l-lg p-3 border border-gray-300">
                                Rp.
                            </div>
                            <input type="text" data-type="money"  value="{{ $mustahik->konsumsi_rokok }}" name="konsumsi_rokok" id="konsumsi_rokok"
                                class="bg-gray-50 border border-gray-300 text-black text-sm rounded-r-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5"
                                placeholder="Masukkan jumlah dalam Rupiah">
                        </div>
                        <select name="jenis_konsumsi_rokok" id="jenis_konsumsi_rokok"
                            class="bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block p-2.5 w-1/2">
                            <option value="3" {{ $mustahik->jenis_konsumsi_rokok == '3' ? 'selected' : '' }}>Tidak ada</option>
                            <option value="2" {{ $mustahik->jenis_konsumsi_rokok == '2' ? 'selected' : '' }}>2 hari 1 bungkus (Rp.300.000 per bulan)</option>
                            <option value="1" {{ $mustahik->jenis_konsumsi_rokok == '1' ? 'selected' : '' }}>1 hari 1 bungkus </option>
                        </select>
                    </div>
                </div>
                <div>
                    <label for="biaya_listrik_air_gas" class="block mb-2 text-xs font-medium text-black">18. Biaya Listrik, Air, Gas, dan Bahan Bakar dalam 1 Bulan</label>
                    <div class="flex gap-2">
                        <div class="flex w-1/2">
                            <div class="text-center self-center text-xs font-medium text-black bg-gray-200 rounded-l-lg p-3 border border-gray-300">
                                Rp.
                            </div>
                            <input type="text" data-type="money"  value="{{ $mustahik->biaya_listrik_air_gas }}" name="biaya_listrik_air_gas" id="biaya_listrik_air_gas"
                                class="bg-gray-50 border border-gray-300 text-black text-sm rounded-r-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5"
                                placeholder="Masukkan jumlah dalam Rupiah">
                        </div>
                        <select name="jenis_biaya_listrik_air_gas" id="jenis_biaya_listrik_air_gas"
                            class="bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block p-2.5 w-1/2">
                            <option value="5" {{ $mustahik->jenis_biaya_listrik_air_gas == '5' ? 'selected' : '' }}>< Rp. 200.000</option>
                            <option value="4" {{ $mustahik->jenis_biaya_listrik_air_gas == '4' ? 'selected' : '' }}>Rp. 200.000 - Rp. 500.000</option>
                            <option value="3" {{ $mustahik->jenis_biaya_listrik_air_gas == '3' ? 'selected' : '' }}>Rp. 500.000 - Rp. 700.000</option>
                            <option value="2" {{ $mustahik->jenis_biaya_listrik_air_gas == '2' ? 'selected' : '' }}>Rp. 700.000 - Rp. 1.000.000</option>
                            <option value="1" {{ $mustahik->jenis_biaya_listrik_air_gas == '1' ? 'selected' : '' }}>> Rp. 1.000.000</option>
                        </select>
                    </div>
                </div>
                <div>
                    <label for="pakaian_kebersihan" class="block mb-2 text-xs font-medium text-black">19. Pakaian untuk Anak-anak dan Orang Dewasa (Mencakup baju lebaran, dan sejenisnya), serta Perawatan Kebersihan Tubuh (Mencakup sabun mandi, kosmetik, dll) dalam 1 Bulan</label>
                    <div class="flex gap-2">
                        <div class="flex w-1/2">
                            <div class="text-center self-center text-xs font-medium text-black bg-gray-200 rounded-l-lg p-3 border border-gray-300">
                                Rp.
                            </div>
                            <input type="text" data-type="money"  value="{{ $mustahik->pakaian_kebersihan }}" name="pakaian_kebersihan" id="pakaian_kebersihan"
                                class="bg-gray-50 border border-gray-300 text-black text-sm rounded-r-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5"
                                placeholder="Masukkan jumlah dalam Rupiah">
                        </div>
                        <select name="jenis_pakaian_kebersihan" id="jenis_pakaian_kebersihan"
                            class="bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block p-2.5 w-1/2">
                            <option value="5" {{ $mustahik->jenis_pakaian_kebersihan == '5' ? 'selected' : '' }}>< Rp. 200.000</option>
                            <option value="4" {{ $mustahik->jenis_pakaian_kebersihan == '4' ? 'selected' : '' }}>Rp. 200.000 - Rp. 500.000</option>
                            <option value="3" {{ $mustahik->jenis_pakaian_kebersihan == '3' ? 'selected' : '' }}>Rp. 500.000 - Rp. 700.000</option>
                            <option value="2" {{ $mustahik->jenis_pakaian_kebersihan == '2' ? 'selected' : '' }}>Rp. 700.000 - Rp. 1.000.000</option>
                            <option value="1" {{ $mustahik->jenis_pakaian_kebersihan == '1' ? 'selected' : '' }}>> Rp. 1.000.000</option>
                        </select>
                    </div>
                </div>

                <div>
                    <label for="komunikasi" class="block mb-2 text-xs font-medium text-black">20. Komunikasi (Pembayaran rekening telepon dan pembelian voucher/isi pulasa, Kartu Perdana, Paket Data Internet)</label>
                    <div class="flex gap-2">
                        <div class="flex w-1/2">
                            <div class="text-center self-center text-xs font-medium text-black bg-gray-200 rounded-l-lg p-3 border border-gray-300">
                                Rp.
                            </div>
                            <input type="text" data-type="money"  value="{{ $mustahik->komunikasi }}" name="komunikasi" id="komunikasi"
                                class="bg-gray-50 border border-gray-300 text-black text-sm rounded-r-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5"
                                placeholder="Masukkan jumlah dalam Rupiah">
                        </div>
                        <select name="jenis_komunikasi" id="jenis_komunikasi"
                            class="bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block p-2.5 w-1/2">
                            <option value="5" {{ $mustahik->jenis_komunikasi == '5' ? 'selected' : '' }}>Tidak ada</option>
                            <option value="4" {{ $mustahik->jenis_komunikasi == '4' ? 'selected' : '' }}>< Rp. 100.000</option>
                            <option value="3" {{ $mustahik->jenis_komunikasi == '3' ? 'selected' : '' }}>Rp. 100.000 - Rp. 250.000</option>
                            <option value="2" {{ $mustahik->jenis_komunikasi == '2' ? 'selected' : '' }}>Rp. 250.000 - Rp. 400.000</option>
                            <option value="1" {{ $mustahik->jenis_komunikasi == '1' ? 'selected' : '' }}>> Rp. 400.000</option>
                        </select>
                    </div>
                </div>

                <div>
                    <label for="transportasi" class="block mb-2 text-xs font-medium text-black">21. Transportasi (Mencakup biaya bis, ojek, angkot, perahu, dan biaya perbaikan kendaraan, bahan bakar kendaraaan, dan sejenisnya)</label>
                    <div class="flex gap-2">
                        <div class="flex w-1/2">
                            <div class="text-center self-center text-xs font-medium text-black bg-gray-200 rounded-l-lg p-3 border border-gray-300">
                                Rp.
                            </div>
                            <input type="text" data-type="money"  value="{{ $mustahik->transportasi }}" name="transportasi" id="transportasi"
                                class="bg-gray-50 border border-gray-300 text-black text-sm rounded-r-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5"
                                placeholder="Masukkan jumlah dalam Rupiah">
                        </div>
                        <select name="jenis_transportasi" id="jenis_transportasi"
                            class="bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block p-2.5 w-1/2">
                            <option value="5" {{ $mustahik->jenis_transportasi == '5' ? 'selected' : '' }}>Tidak ada</option>
                            <option value="4" {{ $mustahik->jenis_transportasi == '4' ? 'selected' : '' }}>< Rp. 100.000</option>
                            <option value="3" {{ $mustahik->jenis_transportasi == '3' ? 'selected' : '' }}>Rp. 100.000 - Rp. 250.000</option>
                            <option value="2" {{ $mustahik->jenis_transportasi == '2' ? 'selected' : '' }}>Rp. 250.000 - Rp. 400.000</option>
                            <option value="1" {{ $mustahik->jenis_transportasi == '1' ? 'selected' : '' }}>> Rp. 400.000</option>
                        </select>
                    </div>
                </div>

                <div>
                    <label for="biaya_sewa" class="block mb-2 text-xs font-medium text-black">22. Biaya Sewa Rumah/Kontrakan</label>
                    <div class="flex gap-2">
                        <div class="flex w-1/2">
                            <div class="text-center self-center text-xs font-medium text-black bg-gray-200 rounded-l-lg p-3 border border-gray-300">
                                Rp.
                            </div>
                            <input type="text" data-type="money"  value="{{ $mustahik->biaya_sewa }}" name="biaya_sewa" id="biaya_sewa"
                                class="bg-gray-50 border border-gray-300 text-black text-sm rounded-r-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5"
                                placeholder="Masukkan jumlah dalam Rupiah">
                        </div>
                        <select name="jenis_biaya_sewa" id="jenis_biaya_sewa"
                            class="bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block p-2.5 w-1/2">
                            <option value="4" {{ $mustahik->jenis_biaya_sewa == '4' ? 'selected' : '' }}> Tidak ada</option>
                            <option value="3" {{ $mustahik->jenis_biaya_sewa == '3' ? 'selected' : '' }}>Rp. 500.000 - Rp. 1.000.000</option>
                            <option value="2" {{ $mustahik->jenis_biaya_sewa == '2' ? 'selected' : '' }}>Rp. 1.000.000 - Rp. 2.000.000</option>
                            <option value="1" {{ $mustahik->jenis_biaya_sewa == '1' ? 'selected' : '' }}>> Rp. 2.000.000</option>

                        </select>
                    </div>
                </div>

                <div>
                    <label for="biaya_sekolah" class="block mb-2 text-xs font-medium text-black">23. Biaya Sekolah (SPP, Uang Saku, Buku, Seragam)</label>
                    <div class="flex gap-2">
                        <div class="flex w-1/2">
                            <div class="text-center self-center text-xs font-medium text-black bg-gray-200 rounded-l-lg p-3 border border-gray-300">
                                Rp.
                            </div>
                            <input type="text" data-type="money"  value="{{ $mustahik->biaya_sekolah }}" name="biaya_sekolah" id="biaya_sekolah"
                                class="bg-gray-50 border border-gray-300 text-black text-sm rounded-r-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5"
                                placeholder="Masukkan jumlah dalam Rupiah">
                        </div>
                        <select name="jenis_biaya_sekolah" id="jenis_biaya_sekolah"
                            class="bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block p-2.5 w-1/2">
                            <option value="5" {{ $mustahik->jenis_biaya_sekolah == '5' ? 'selected' : '' }}>Tidak ada</option>
                            <option value="4" {{ $mustahik->jenis_biaya_sekolah == '4' ? 'selected' : '' }}>< Rp. 200.000 - Rp. 500.000</option>
                            <option value="3" {{ $mustahik->jenis_biaya_sekolah == '3' ? 'selected' : '' }}>Rp. 500.000 - Rp. 1.000.000</option>
                            <option value="2" {{ $mustahik->jenis_biaya_sekolah == '2' ? 'selected' : '' }}>Rp. 1.000.000 - Rp. 2.000.000</option>
                            <option value="1" {{ $mustahik->jenis_biaya_sekolah == '1' ? 'selected' : '' }}>> Rp. 2.000.000</option>
                        </select>
                    </div>
                </div>

                <div>
                    <label for="biaya_kesehatan" class="block mb-2 text-xs font-medium text-black">24. Biaya Kesehatan (Mencakup biaya rumah sakit, puskesmas, konsultasi dokter mantri, obat-obatan, dan lainya)</label>
                    <div class="flex gap-2">
                        <div class="flex w-1/2">
                            <div class="text-center self-center text-xs font-medium text-black bg-gray-200 rounded-l-lg p-3 border border-gray-300">
                                Rp.
                            </div>
                            <input type="text" data-type="money"  value="{{ $mustahik->biaya_kesehatan }}" name="biaya_kesehatan" id="biaya_kesehatan"
                                class="bg-gray-50 border border-gray-300 text-black text-sm rounded-r-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5"
                                placeholder="Masukkan jumlah dalam Rupiah">
                        </div>
                        <select name="jenis_biaya_kesehatan" id="jenis_biaya_kesehatan"
                            class="bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block p-2.5 w-1/2">
                            <option value="5" {{ $mustahik->jenis_biaya_kesehatan == '5' ? 'selected' : '' }}>> Rp. 2.500.000</option>
                            <option value="4" {{ $mustahik->jenis_biaya_kesehatan == '4' ? 'selected' : '' }}>Rp. 1.500.000 - Rp. 2.500.000</option>
                            <option value="3" {{ $mustahik->jenis_biaya_kesehatan == '3' ? 'selected' : '' }}>Rp. 500.000 - Rp. 1.500.000</option>
                            <option value="2" {{ $mustahik->jenis_biaya_kesehatan == '2' ? 'selected' : '' }}>Tidak ada</option>
                        </select>
                    </div>
                </div>
                <div>
                    <label for="angsuran_kredit" class="block mb-2 text-xs font-medium text-black">25. Angsuran Kredit</label>
                    <div class="flex gap-2">
                        <div class="flex w-1/3">
                            <div class="text-center self-center text-xs font-medium text-black bg-gray-200 rounded-l-lg p-3 border border-gray-300">
                                Rp.
                            </div>
                            <input type="text" data-type="money"  value="{{ $mustahik->angsuran_kredit }}" name="angsuran_kredit" id="angsuran_kredit"
                                class="bg-gray-50 border border-gray-300 text-black text-sm rounded-r-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5"
                                placeholder="Masukkan jumlah dalam Rupiah">
                        </div>
                        <select name="jenis_angsuran_kredit" id="jenis_angsuran_kredit"
                            class="bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block p-2.5 w-1/3">
                            <option value="5" {{ $mustahik->jenis_angsuran_kredit == '5' ? 'selected' : '' }}>Tidak ada</option>
                            <option value="4" {{ $mustahik->jenis_angsuran_kredit == '4' ? 'selected' : '' }}> < Rp. 1.000.000</option>
                            <option value="3" {{ $mustahik->jenis_angsuran_kredit == '3' ? 'selected' : '' }}>Rp. 1.000.000 - Rp. 2.500.000</option>
                            <option value="2" {{ $mustahik->jenis_angsuran_kredit == '2' ? 'selected' : '' }}>>Rp. 2.500.000 </option>
                        </select>
                        <div class="flex w-1/3">
                            <div class="text-center self-center text-xs font-medium text-black bg-gray-200 rounded-l-lg p-3 border border-gray-300">
                                Keterangan
                            </div>
                            <input type="text" name="keterangan_angsuran_kredit" id="keterangan_angsuran_kredit"
                                class="bg-gray-50 border border-gray-300 text-black text-sm rounded-r-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5"
                                placeholder="(Opsional) Isikan keterangan angsuran" value="{{ $mustahik->keterangan_angsuran_kredit }}">
                        </div>
                    </div>
                </div>

                <div>
                    <label for="kategori_pengeluaran" class="block mb-2 text-xs font-medium text-black">26. Kategori Pengeluaran per Bulan</label>
                    <select name="kategori_pengeluaran" id="kategori_pengeluaran"
                        class="bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5">
                        <option value="5" {{ $mustahik->kategori_pengeluaran == '5' ? 'selected' : '' }}>< Rp 2.000.000</option>
                        <option value="4" {{ $mustahik->kategori_pengeluaran == '4' ? 'selected' : '' }}>Rp 2.000.000 - Rp 3.000.000</option>
                        <option value="3" {{ $mustahik->kategori_pengeluaran == '3' ? 'selected' : '' }}>Rp 3.000.000 - Rp 5.000.000</option>
                        <option value="2" {{ $mustahik->kategori_pengeluaran == '2' ? 'selected' : '' }}>Rp 5.000.000 - Rp 7.000.000</option>
                        <option value="1" {{ $mustahik->kategori_pengeluaran == '1' ? 'selected' : '' }}>> Rp 7.000.000</option>
                    </select>
                </div>

                <div>
                    <label for="tabungan_bank" class="block mb-2 text-xs font-medium text-black">27. Tabungan di Bank</label>
                    <select name="tabungan_bank" id="tabungan_bank"
                        class="bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5">
                        <option value="3" {{ $mustahik->tabungan_bank == '3' ? 'selected' : '' }}>Tidak Ada</option>
                        <option value="2" {{ $mustahik->tabungan_bank == '2' ? 'selected' : '' }}>Ada</option>
                    </select>
                </div>
                <div>
                    <label for="memiliki_bpjs" class="block mb-2 text-xs font-medium text-black">28. Memiliki BPJS</label>
                    <div class="flex gap-2">
                        <select name="memiliki_bpjs" id="memiliki_bpjs"
                            class="bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-1/2 p-2.5">
                            <option value="4" {{ $mustahik->memiliki_bpjs == '4' ? 'selected' : '' }}>Tidak Ada</option>
                            <option value="2" {{ $mustahik->memiliki_bpjs == '2' ? 'selected' : '' }}>Ada</option>
                        </select>
                        <div class="flex w-1/2">
                            <div class="text-center self-center text-xs font-medium text-black bg-gray-200 rounded-l-lg p-3 border border-gray-300">
                                Keterangan
                            </div>
                            <input type="text" name="keterangan_bpjs" id="keterangan_bpjs"
                                class="bg-gray-50 border border-gray-300 text-black text-sm rounded-r-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5"
                                placeholder="(Opsional) Isikan keterangan BPJS" value="{{ $mustahik->keterangan_bpjs }}">
                        </div>
                    </div>
                </div>

                <div>
                    <label for="asuransi_pendidikan" class="block mb-2 text-xs font-medium text-black">29. Asuransi Pendidikan</label>
                    <div class="flex gap-2">
                        <select name="asuransi_pendidikan" id="asuransi_pendidikan"
                            class="bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-1/2 p-2.5">
                            <option value="4" {{ $mustahik->asuransi_pendidikan == '4' ? 'selected' : '' }}>Tidak Ada</option>
                            <option value="2" {{ $mustahik->asuransi_pendidikan == '2' ? 'selected' : '' }}>Ada</option>
                        </select>
                        <div class="flex w-1/2">
                            <div class="text-center self-center text-xs font-medium text-black bg-gray-200 rounded-l-lg p-3 border border-gray-300">
                                Keterangan
                            </div>
                            <input type="text" name="keterangan_asuransi_pendidikan" id="keterangan_asuransi_pendidikan"
                                class="bg-gray-50 border border-gray-300 text-black text-sm rounded-r-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5"
                                placeholder="(Opsional) Isikan keterangan asuransi pendidikan" value="{{ $mustahik->keterangan_asuransi_pendidikan }}">
                        </div>
                    </div>
                </div>

                <div>
                    <label for="deposito" class="block mb-2 text-xs font-medium text-black">30. Deposito dan Tabungan Hari Tua</label>
                    <div class="flex gap-2">
                        <select name="deposito" id="deposito"
                            class="bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-1/2 p-2.5">
                            <option value="4" {{ $mustahik->deposito == '4' ? 'selected' : '' }}>Tidak Ada</option>
                            <option value="2" {{ $mustahik->deposito == '2' ? 'selected' : '' }}>Ada</option>
                        </select>
                        <div class="flex w-1/2">
                            <div class="text-center self-center text-xs font-medium text-black bg-gray-200 rounded-l-lg p-3 border border-gray-300">
                                Keterangan
                            </div>
                            <input type="text" name="keterangan_deposito" id="keterangan_deposito"
                                class="bg-gray-50 border border-gray-300 text-black text-sm rounded-r-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5"
                                placeholder="(Opsional) Isikan keterangan deposito" value="{{ $mustahik->keterangan_deposito }}">
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </section>
        <section id="identifikasi_tempat_tinggal" class="my-4 space-y-4 analisis">
            <p class="block py-4 text-base font-semibold text-black">
                VI. Identifikasi Kondisi Tempat Tinggal dan Lingkungan
            </p>

            <div class="space-y-4">
                <div>
                    <label for="kepemilikan_tempat_tinggal" class="block mb-2 text-xs font-medium text-black">31. Kepemilikan Tempat Tinggal</label>
                    <select name="kepemilikan_tempat_tinggal" id="kepemilikan_tempat_tinggal"
                        class="bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5">
                        <option value="5" {{ $mustahik->kepemilikan_tempat_tinggal == '5' ? 'selected' : '' }}> Menumpang / tidak jelas</option>
                        <option value="4" {{ $mustahik->kepemilikan_tempat_tinggal == '4' ? 'selected' : '' }}>Kontrak</option>
                        <option value="3" {{ $mustahik->kepemilikan_tempat_tinggal == '3' ? 'selected' : '' }}>Bersama / Keluarga</option>
                        <option value="2" {{ $mustahik->kepemilikan_tempat_tinggal == '2' ? 'selected' : '' }}>Sendiri/Warisan</option>
                    </select>
                </div>

                <div>
                    <label for="bentuk_bangunan" class="block mb-2 text-xs font-medium text-black">32. Bentuk Bangunan</label>
                    <select name="bentuk_bangunan" id="bentuk_bangunan"
                        class="bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5">
                        <option value="4" {{ $mustahik->bentuk_bangunan == '4' ? 'selected' : '' }}>Tidak Permanen</option>
                        <option value="3" {{ $mustahik->bentuk_bangunan == '3' ? 'selected' : '' }}>Semi Permanen</option>
                        <option value="2" {{ $mustahik->bentuk_bangunan == '2' ? 'selected' : '' }}>Permanen</option>
                    </select>

                </div>

                <div>
                    <label for="desain_bangunan" class="block mb-2 text-xs font-medium text-black">33. Desain Bangunan</label>
                    <select name="desain_bangunan" id="desain_bangunan"
                        class="bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5">
                        <option value="3" {{ $mustahik->desain_bangunan == '3' ? 'selected' : '' }}> 1 Lantai</option>
                        <option value="2" {{ $mustahik->desain_bangunan == '2' ? 'selected' : '' }}> 2 Lantai</option>
                        <option value="1" {{ $mustahik->desain_bangunan == '1' ? 'selected' : '' }}> lebih dari 2 Lantai</option>
                    </select>
                </div>

                <div>
                    <label for="lokasi_rumah" class="block mb-2 text-xs font-medium text-black">34. Lokasi Rumah</label>
                    <select name="lokasi_rumah" id="lokasi_rumah"
                        class="bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5">
                        <option value="5" {{ $mustahik->lokasi_rumah == '5' ? 'selected' : '' }}>Bantaran kali</option>
                        <option value="4" {{ $mustahik->lokasi_rumah == '4' ? 'selected' : '' }}>Kampung kumuh</option>
                        <option value="3" {{ $mustahik->lokasi_rumah == '3' ? 'selected' : '' }}>Kampung biasa</option>
                        <option value="2" {{ $mustahik->lokasi_rumah == '2' ? 'selected' : '' }}>Komplek</option>
                        <option value="1" {{ $mustahik->lokasi_rumah == '1' ? 'selected' : '' }}>Kluster</option>
                    </select>
                </div>

                <div>
                    <label for="tata_letak_lingkungan" class="block mb-2 text-xs font-medium text-black">35. Tata Letak Lingkungan pada Umumnya</label>
                    <select name="tata_letak_lingkungan" id="tata_letak_lingkungan"
                        class="bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5">
                        <option value="5" {{ $mustahik->tata_letak_lingkungan == '5' ? 'selected' : '' }}>Kumuh dan padat</option>
                        <option value="4" {{ $mustahik->tata_letak_lingkungan == '4' ? 'selected' : '' }}>Kurang teratur</option>
                        <option value="3" {{ $mustahik->tata_letak_lingkungan == '3' ? 'selected' : '' }}>Teratur</option>
                        <option value="2" {{ $mustahik->tata_letak_lingkungan == '2' ? 'selected' : '' }}>Sangat teratur</option>
                    </select>
                </div>

                <div>
                    <label for="akses_rumah_ke_jalan" class="block mb-2 text-xs font-medium text-black">36. Akses Rumah ke Jalan</label>
                    <select name="akses_rumah_ke_jalan" id="akses_rumah_ke_jalan"
                        class="bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5">
                        <option value="5" {{ $mustahik->akses_rumah_ke_jalan == '5' ? 'selected' : '' }}>Gang Sangat Kecil</option>
                        <option value="4" {{ $mustahik->akses_rumah_ke_jalan == '4' ? 'selected' : '' }}>Gang kecil jalan 2 motor</option>
                        <option value="3" {{ $mustahik->akses_rumah_ke_jalan == '3' ? 'selected' : '' }}>Pinggir jalan 1 mobil</option>
                        <option value="2" {{ $mustahik->akses_rumah_ke_jalan == '2' ? 'selected' : '' }}>Pinggir jalan 2 mobil</option>
                    </select>
                </div>
            </div>
        </section>
        <section id="identifikasi_kepemilikan" class="my-4 space-y-4 analisis">
            <p class="block py-4 text-base font-semibold text-black">
                VI. Identifikasi Kepemilikan
            </p>

            <div class="space-y-4">
                <div>
                    <label for="kendaraan_transportasi" class="block mb-2 text-xs font-medium text-black">37. Kendaraan/Transportasi</label>
                    <select name="kendaraan_transportasi" id="kendaraan_transportasi"
                        class="bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5">
                        <option value="5" {{ $mustahik->kendaraan_transportasi == '5' ? 'selected' : '' }}>Tidak Ada</option>
                        <option value="4" {{ $mustahik->kendaraan_transportasi == '4' ? 'selected' : '' }}>hanya sepeda</option>
                        <option value="3" {{ $mustahik->kendaraan_transportasi == '3' ? 'selected' : '' }}>motor</option>
                        <option value="2" {{ $mustahik->kendaraan_transportasi == '2' ? 'selected' : '' }}>motor lebih dari 1</option>
                        <option value="1" {{ $mustahik->kendaraan_transportasi == '1' ? 'selected' : '' }}>mobil</option>
                    </select>
                </div>

                <div>
                    <label for="usaha_dagang_produksi" class="block mb-2 text-xs font-medium text-black">38. Usaha Dagang/Produksi</label>
                    <select name="usaha_dagang_produksi" id="usaha_dagang_produksi"
                        class="bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5">
                        <option value="4" {{ $mustahik->usaha_dagang_produksi == '4' ? 'selected' : '' }}>Tidak Ada</option>
                        <option value="3" {{ $mustahik->usaha_dagang_produksi == '3' ? 'selected' : '' }}>Warung Kecil</option>
                        <option value="2" {{ $mustahik->usaha_dagang_produksi == '2' ? 'selected' : '' }}>Toko / tani/ ternak/ home industri kecil</option>
                        <option value="1" {{ $mustahik->usaha_dagang_produksi == '1' ? 'selected' : '' }}>Ruko/ industri menengah</option>
                    </select>
                </div>

                <div>
                    <label for="usaha_sampingan_jasa" class="block mb-2 text-xs font-medium text-black">39. Usaha Sampingan Jasa</label>
                    <select name="usaha_sampingan_jasa" id="usaha_sampingan_jasa"
                        class="bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5">
                        <option value="4" {{ $mustahik->usaha_sampingan_jasa == '4' ? 'selected' : '' }}>Tidak Ada / Serabutan</option>
                        <option value="3" {{ $mustahik->usaha_sampingan_jasa == '3' ? 'selected' : '' }}>Ojek Online</option>
                        <option value="2" {{ $mustahik->usaha_sampingan_jasa == '2' ? 'selected' : '' }}>Usaha tetap/ bulanan</option>
                    </select>
                </div>

                <div>
                    <label for="usaha_pendapatan_sewa_aktiva" class="block mb-2 text-xs font-medium text-black">40. Usaha dari Pendapatan Sewa Aktiva</label>
                    <select name="usaha_pendapatan_sewa_aktiva" id="usaha_pendapatan_sewa_aktiva"
                        class="bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5">
                        <option value="3" {{ $mustahik->usaha_pendapatan_sewa_aktiva == '3' ? 'selected' : '' }}>Tidak Ada</option>
                        <option value="2" {{ $mustahik->usaha_pendapatan_sewa_aktiva == '2' ? 'selected' : '' }}>Alat Produksi/ Kendaraan</option>
                        <option value="1" {{ $mustahik->usaha_pendapatan_sewa_aktiva == '1' ? 'selected' : '' }}>Tanah/ Rumah/ Kios/ Kontrakan</option>
                    </select>
                </div>
            </div>
        </section>
        <section id="identifikasi_scoring" class="my-4 space-y-4 analisis">
          <p class="block py-4 text-base font-semibold text-black">
              VII. Hasil Scoring Kelayakan
          </p>

          <div class="flex gap-12 justify-between">
            <div class="">
              <label for="total_nilai" class="block mb-2 text-xs font-medium text-black">Total Nilai :</label> 
              <div class="flex gap-4">
                <div class="text-center self-center text-xl font-medium text-black bg-gray-50 rounded-lg px-2.5 py-5 border border-gray-300 flex items-center">
                  <input id="total_nilai" readonly value="{{ $mustahik->total_nilai }}" name="total_nilai" class="w-40 bg-transparent text-right mr-2 focus:outline-none">
                  <p class="whitespace-nowrap">/40 =</p>
                </div>
                <input type="text" name="nilai_akhir" id="nilai_akhir" readonly
                  class="bg-gray-50 border border-gray-300 text-black text-xl text-center rounded-lg flex px-2.5 py-5 w-36 focus:outline-none focus:ring-none focus:border-none" value="{{ $mustahik->nilai_akhir }}">
              </div>

            </div>
            <div class="">
              <label for="rekomendasi_scoring" class="block mb-2 text-xs text-center font-medium text-black">Rekomendasi Scoring</label>
              <div class="flex gap-2">
                <button type="button" id="rekomendasi_ya" class="px-4 py-6 w-28 bg-gray-50 text-black rounded-lg border border-gray-300 {{ $mustahik->rekomendasi_scoring == '1' ? 'bg-gray-200 border-green-500 border-2' : '' }}">Ya</button>
                <button type="button" id="rekomendasi_tidak" class="px-4 py-6 w-28 bg-gray-50 text-black rounded-lg border border-gray-300 {{ $mustahik->rekomendasi_scoring == '0' ? 'bg-gray-200 border-green-500 border-2' : '' }}">Tidak</button>
                <input type="hidden" name="rekomendasi_scoring" id="rekomendasi_scoring" value="{{ $mustahik->rekomendasi_scoring }}">
              </div>
            </div>
            <script>
              document.getElementById('rekomendasi_ya').addEventListener('click', function() {
                this.classList.add('bg-gray-200', 'border-green-500', 'border-2');
                this.classList.remove('bg-gray-50', 'border-gray-300');
                document.getElementById('rekomendasi_tidak').classList.add('bg-gray-50', 'border-gray-300');
                document.getElementById('rekomendasi_tidak').classList.remove('bg-gray-200', 'border-green-500', 'border-2');
                document.getElementById('rekomendasi_scoring').value = '1';
              });
              
              document.getElementById('rekomendasi_tidak').addEventListener('click', function() {
                this.classList.add('bg-gray-200', 'border-green-500', 'border-2');
                this.classList.remove('bg-gray-50', 'border-gray-300');
                document.getElementById('rekomendasi_ya').classList.add('bg-gray-50', 'border-gray-300');
                document.getElementById('rekomendasi_ya').classList.remove('bg-gray-200', 'border-green-500', 'border-2');
                document.getElementById('rekomendasi_scoring').value = '0';
              });
            </script>
          </div>
      </section>
        <section id="catatan_surveyor" class="my-4 space-y-4">
          <p class="block py-4 text-base font-semibold text-black">
              VIII. Catatan/Rekomendasi Surveyor/Pewawancara
          </p>

          <div class="space-y-4">
            <div>
              <label for="akurasi_alamat" class="block mb-2 text-xs font-medium text-black">Akurasi Alamat</label>
              <select name="akurasi_alamat" id="akurasi_alamat"
                  class="bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5">
                  <option value="1" {{ $mustahik->akurasi_alamat == '1' ? 'selected' : '' }}>Ya</option>
                  <option value="2" {{ $mustahik->akurasi_alamat == '2' ? 'selected' : '' }}>Tidak</option>
              </select>
            </div>

            <div>
              <label for="kelayakan_mustahik" class="block mb-2 text-xs font-medium text-black">Kelayakan Mustahik</label>
              <select name="kelayakan_mustahik" id="kelayakan_mustahik"
                  class="bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5">
                  <option value="1" {{ $mustahik->kelayakan_mustahik == '1' ? 'selected' : '' }}>Ya</option>
                  <option value="2" {{ $mustahik->kelayakan_mustahik == '2' ? 'selected' : '' }}>Tidak</option>
                  <option value="3" {{ $mustahik->kelayakan_mustahik == '3' ? 'selected' : '' }}>dipertimbangkan</option>
              </select>
            </div>

            <div>
              <label for="analisis_rekomendasi" class="block mb-2 text-xs font-medium text-black">Analisis dan Rekomendasi Surveyor</label>
              <textarea id="analisis_rekomendasi" name="analisis_rekomendasi" rows="4" 
                  class="bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5"
                  placeholder="Tuliskan analisis rekomendasi surveypr terhadap kelayakan mustahik dari hasil survey">{{ $mustahik->analisis_rekomendasi }}</textarea>
            </div>
          </div>
        </section>
        <section>
          <div>
              <label for="kode_koordinat" class="block mb-2 text-xs font-medium text-black">Kode titik koordinat (Share Lokasi Google Maps)</label>
              <input type="text" name="kode_koordinat" id="kode_koordinat" class="bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5" value="{{ $mustahik->kode_koordinat }}">
          </div>
        </section>
        <section>
            <div class="mb-4 flex justify-between">
                <label for="paraf_disurvey" class="block my-2 font-medium text-black">Paraf yang disurvey:</label>
                <button type="button" id="clear_paraf_disurvey" class="font-medium text-red-500 underline">Hapus Paraf</button>
            </div>
            @if($mustahik->signed_disurvey)
                <img src="/storage/{{ $mustahik->signed_disurvey }}" alt="Paraf yang disurvey" class="border object-contain border-gray-300 w-full rounded-lg p-2" style="height: 200px;" id="image_disurvey">
                <input type="hidden" name="old_signed_disurvey" value="{{ $mustahik->signed_disurvey }}">
            @endif
                <div id="sig_disurvey" class="signature border border-gray-300 w-full rounded-lg p-2 hidden" style="height: 200px;"></div>
            
            <textarea id="signature64_disurvey" name="signed_disurvey" style="display: none"></textarea>
        </section>
        <section>
            <div class="mb-4 flex justify-between">
                <label for="paraf_koordinator" class="block my-2 font-medium text-black">Koordinator Survey:</label>
                <button type="button" id="clear_paraf_koordinator" class="font-medium text-red-500 underline">Hapus Paraf</button>
            </div>
            @if($mustahik->signed_koordinator)
                <img src="/storage/{{ $mustahik->signed_koordinator }}" alt="Koordinator Survey" class="border object-contain border-gray-300 w-full rounded-lg p-2" style="height: 200px;" id="image_koordinator">
                <input type="hidden" name="old_signed_koordinator" value="{{ $mustahik->signed_koordinator }}">
            @endif
                <div id="sig_koordinator" class="signature border border-gray-300 w-full rounded-lg p-2 hidden " style="height: 200px;"></div>
            
            <textarea id="signature64_koordinator" name="signed_koordinator" style="display: none"></textarea>
        </section>
        <section>
            <div class="mb-4 flex justify-between">
                <label for="paraf_surveyor" class="block my-2 font-medium text-black">Paraf Surveyor:</label>
                <button type="button" id="clear_paraf_surveyor" class="font-medium text-red-500 underline">Hapus Paraf</button>
            </div>
            @if($mustahik->signed_surveyor)
                <img src="/storage/{{ $mustahik->signed_surveyor }}" alt="Paraf Surveyor" class="border object-contain border-gray-300 w-full rounded-lg p-2" style="height: 200px;" id="image_surveyor">
                <input type="hidden" name="old_signed_surveyor" value="{{ $mustahik->signed_surveyor }}">
            @endif
                <div id="sig_surveyor" class="signature border border-gray-300 w-full rounded-lg p-2 hidden" style="height: 200px;"></div>
            
              <textarea id="signature64_surveyor" name="signed_surveyor" style="display: none"></textarea>
        </section>
        
        <div class=" pt-6">
            <button type="submit"
                class="text-white bg-green-500 hover:bg-green-600 w-full focus:ring-4 focus:outline-none font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 my-2">Simpan</button>
        </div>
    </form>

    <script type="text/javascript">
$(document).ready(function () {
    // Initialize signature pads only when needed
    let sig_disurvey, sig_koordinator, sig_surveyor;

    
    // Clear signature handlers
    $('#clear_paraf_disurvey').click(function (e) {
        e.preventDefault();
        $("#sig_disurvey").removeClass("hidden").jSignature({  'UndoButton': true });
        $("#image_disurvey").remove();
        sig_disurvey = $("#sig_disurvey");
        sig_disurvey.jSignature("reset");
        $("#signature64_disurvey").val('');
    });

    $('#clear_paraf_koordinator').click(function (e) {
        e.preventDefault();
        $("#sig_koordinator").removeClass("hidden").jSignature({  'UndoButton': true });
        $("#image_koordinator").remove();
        sig_koordinator = $("#sig_koordinator");
        sig_koordinator.jSignature("reset");
        $("#signature64_koordinator").val('');
    });

    $('#clear_paraf_surveyor').click(function (e) {
        e.preventDefault();
        $("#sig_surveyor").removeClass("hidden").jSignature({  'UndoButton': true });
        $("#image_surveyor").remove();
        sig_surveyor = $("#sig_surveyor");
        sig_surveyor.jSignature("reset");
        $("#signature64_surveyor").val('');
    });

    // Capture signature on form submission
    $("form").submit(function () {
        if (sig_disurvey) {
            var data_disurvey = sig_disurvey.jSignature("getData", "svgbase64");
            $("#signature64_disurvey").val(data_disurvey);
        }

        if (sig_koordinator) {
            var data_koordinator = sig_koordinator.jSignature("getData", "svgbase64");
            $("#signature64_koordinator").val(data_koordinator);
        }

        if (sig_surveyor) {
            var data_surveyor = sig_surveyor.jSignature("getData", "svgbase64");
            $("#signature64_surveyor").val(data_surveyor);
        }
    });
});


    </script>
    <script>
        $(document).ready(function () {
            hitungTotalNilai();
            $(".analisis select").change(function () {
                hitungTotalNilai();
            });
        });

        function hitungTotalNilai() {
            var total = 0;
            $(".analisis select").each(function () {
                total += parseInt($(this).val())*20;
            });
            $("#total_nilai").val(total);
            $("#nilai_akhir").val(total / 40);              
        }
    </script>
              
    <script>
        $("input[data-type='money']").on({
            keyup: function() {
                formatCurrency($(this));
            },
            blur: function() {
                formatCurrency($(this), "blur");
            }
        });


        function formatNumber(n) {
            // format number 1000000 to 1,234,567
            return n.replace(/\D/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, ".");
        }


        function formatCurrency(input, blur) {
            // appends $ to value, validates decimal side
            // and puts cursor back in right position.

            // get input value
            var input_val = input.val();

            // don't validate empty input
            if (input_val === "") {
                return;
            }

            // original length
            var original_len = input_val.length;

            // initial caret position 
            var caret_pos = input.prop("selectionStart");

            // check for decimal
            if (input_val.indexOf(",") >= 0) {

                // get position of first decimal
                // this prevents multiple decimals from
                // being entered
                var decimal_pos = input_val.indexOf(",");

                // split number by decimal point
                var left_side = input_val.substring(0, decimal_pos);
                var right_side = input_val.substring(decimal_pos);

                // add commas to left side of number
                left_side = formatNumber(left_side);

                // validate right side
                right_side = formatNumber(right_side);

                // On blur make sure 2 numbers after decimal
                if (blur === "blur") {
                    right_side += "00";
                }

                // Limit decimal to only 2 digits
                right_side = right_side.substring(0, 2);

                // join number by .
                input_val = left_side + "," + right_side;

            } else {
                // no decimal entered
                // add commas to number
                // remove all non-digits
                input_val = formatNumber(input_val);
                input_val = input_val;

                // final formatting
                if (blur === "blur") {
                    input_val += ",00";
                }
            }

            // send updated string to input
            input.val(input_val);

            // put caret back in the right position
            var updated_len = input_val.length;
            caret_pos = updated_len - original_len + caret_pos;
            input[0].setSelectionRange(caret_pos, caret_pos);
        }
    </script>
    @if (session('success-add'))
        <script>
            alert("Data berhasil ditambah!")
        </script>
    @endif

    @if (session('success-edit'))
        <script>
            alert("Data berhasil diedit!")
        </script>
    @endif
@endsection

<nav class="bg-white border-gray-200 dark:bg-gray-900 fixed h-20 z-50 border-b-2 w-screen">
    <div class="w-full max-w-screen-xl flex flex-wrap items-center justify-between mx-auto p-4 px-20">
        <a href="/" class="flex items-center">
            <img src="{{ asset('img/logo.png') }}" class="h-12 mr-3" alt="Baznas Logo" />
            <p class=" font-bold">Baznas DKI</p>
        </a>
        <button data-collapse-toggle="navbar-default" type="button"
            class="inline-flex items-center p-2 w-10 h-10 justify-center text-sm text-black rounded-lg hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200 "
            aria-controls="navbar-default" aria-expanded="false">
            <span class="sr-only">Open main menu</span>
            <svg class="w-5 h-5" aria-hidden="true" xmlns="https://www.w3.org/2000/svg" fill="none"
                viewBox="0 0 17 14">
                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M1 1h15M1 7h15M1 13h15" />
            </svg>
        </button>
    </div>
    <div class="hidden p-2 px-20 bg-white w-screen mx-auto border-b border-gray-200" id="navbar-default">

        <div class="max-w-screen-xl w-full mx-auto flex flex-col">
            <div class="mt-4 bg-green-500 rounded-md p-4 drop-shadow-lg">
                <p class="text-left font-bold text-sm text-white">
                    User : <span class="font-normal">{{ Auth::user()->username }}</span>
                </p>
                <p class="text-left font-bold text-sm text-white">
                    Nama : <span class="font-normal">{{ Auth::user()->name }}</span>
                </p>
            </div>
            <div class="mt-6">
                <nav class="-mx-3 space-y-6 ">
                    <div id="exit" class="space-y-2 ">


                        <form action="{{ Route('logout') }}" method="post" 
                            class="flex items-center w-full px-4 py-2 text-black transition-colors duration-300 rounded-lg hover:bg-red-600 hover:text-white">
                            @csrf
                            <button class=" flex items-center w-full">
                                <svg xmlns="https://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                    stroke-width="1.5" stroke="currentColor" class="w-5 h-5">
                                    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                    <path
                                        d="M14 8v-2a2 2 0 0 0 -2 -2h-7a2 2 0 0 0 -2 2v12a2 2 0 0 0 2 2h7a2 2 0 0 0 2 -2v-2">
                                    </path>
                                    <path d="M9 12h12l-3 -3"></path>
                                    <path d="M18 15l3 -3"></path>
                                </svg>
                                <span class="mx-2 text-sm font-medium">Log Off</span>
                            </button>
                        </form>
                    </div>
                </nav>
            </div>
        </div>

    </div>
</nav>
